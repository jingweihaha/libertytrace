﻿namespace LibertyHealthcare.PAAPS.Core.Domains
{
    public class MenuItem
    {
        public int MenuId;
        public string MenuText;
    }
}