﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibertyHealthcare.PAAPS.Core.Domains
{
    public class UserCase
    {
    }
}
