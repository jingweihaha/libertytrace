﻿using LibertyHealthcare.PAAPS.Core.Domains;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LibertyHealthcare.PAAPS.Core.Interfaces
{
    public interface IUserCasesService : IBaseService<UserCase>
    {
       

        
    }
}
