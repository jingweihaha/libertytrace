﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LibertyHealthcare.PAAPS.Core.Interfaces
{
    public interface IBaseService<T>
    {
        
        Task CreateOneAsync(T t);
        Task<T> SearchOneAsync(T t);
        Task<List<T>> LoadAllAsync();
        Task UpdateOneAsync(T t);
        Task DeleteOneAsync(T t);

    }

    
}
