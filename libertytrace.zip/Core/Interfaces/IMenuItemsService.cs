﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using LibertyHealthcare.PAAPS.Core.Domains;

namespace LibertyHealthcare.PAAPS.Core.Interfaces
{
    public interface IMenuItemsService:IBaseService<MenuItem>
    {
        List<MenuItem> LoadAllMenuItems();
    }
}
