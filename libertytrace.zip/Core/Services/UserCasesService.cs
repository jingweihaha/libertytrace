﻿using LibertyHealthcare.PAAPS.Core.Domains;
using LibertyHealthcare.PAAPS.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace LibertyHealthcare.PAAPS.Core.Services
{
    public class UserCasesService : IUserCasesService
    {
        public Task CreateOneAsync(UserCase t)
        {
            throw new NotImplementedException();
        }

        public Task DeleteOneAsync(UserCase t)
        {
            throw new NotImplementedException();
        }

        public Task<List<UserCase>> LoadAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<UserCase> SearchOneAsync(UserCase t)
        {
            throw new NotImplementedException();
        }

        public Task UpdateOneAsync(UserCase t)
        {
            throw new NotImplementedException();
        }
    }
}
