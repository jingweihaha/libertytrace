﻿using LibertyHealthcare.PAAPS.Core.Domains;
using LibertyHealthcare.PAAPS.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LibertyHealthcare.PAAPS.Core.Services
{
    public class MenuItemsService : IMenuItemsService
    {
        public Task CreateOneAsync(MenuItem t)
        {
            throw new NotImplementedException();
        }

        public Task DeleteOneAsync(MenuItem t)
        {
            throw new NotImplementedException();
        }

        public Task<List<MenuItem>> LoadAllAsync()
        {
            throw new NotImplementedException();
        }

        public List<MenuItem> LoadAllMenuItems()
        {
            Thread.Sleep(10000);
            List<MenuItem> menuItemsList = new List<MenuItem>();
            menuItemsList.Add(new MenuItem() { MenuId = 1, MenuText = "All Cases" });
            menuItemsList.Add(new MenuItem() { MenuId = 2, MenuText = "My Cases" });
            menuItemsList.Add(new MenuItem() { MenuId = 3, MenuText = "Consumer Search" });
            return menuItemsList;
        }

        public Task<MenuItem> SearchOneAsync(MenuItem t)
        {
            throw new NotImplementedException();
        }

        public Task UpdateOneAsync(MenuItem t)
        {
            throw new NotImplementedException();
        }
    }
}
